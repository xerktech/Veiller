(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __toESM = (mod, isNodeMode, target) => {
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: () => mod[key],
          enumerable: true
        });
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3());

  // ../../mobile/modules/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../../mobile/modules/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../../mobile/modules/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType2["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType2["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../../mobile/modules/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../../mobile/modules/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../../cloud-v2/packages/protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../../mobile/modules/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../../mobile/modules/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../../mobile/modules/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/core/transcript.ts
  function emptyBuffer() {
    return { entries: [] };
  }
  var TOOL_MARKER = /\[[A-Za-z][A-Za-z0-9_]*\]/g;
  function stripMarkdown(text) {
    const lines = text.split(`
`).map((line) => {
      if (/^\s*```/.test(line))
        return "";
      return line.replace(/^\s{0,3}#{1,6}\s+/, "").replace(/^(\s*)[-*+]\s+/, "$1• ").replace(/^\s{0,3}>\s?/, "");
    });
    return lines.join(`
`).replace(/`([^`]+)`/g, "$1").replace(/\*\*([^*]+)\*\*/g, "$1");
  }
  function collapseBlankLines(text) {
    return text.split(`
`).filter((line) => line.trim() !== "").join(`
`);
  }
  function conciseText(text) {
    const stripped = stripMarkdown(text.replace(TOOL_MARKER, ""));
    return collapseBlankLines(stripped).replace(/[ \t]+$/gm, "").trim();
  }
  function conciseEntry(entry) {
    const text = entry.role === "assistant" ? conciseText(entry.text) : collapseBlankLines(entry.text);
    return text === entry.text ? entry : { ...entry, text };
  }
  function mergeTail(buffer, tail) {
    if (tail.length === 0)
      return buffer;
    const entries = buffer.entries.slice();
    const indexById = new Map(entries.map((e, i) => [e.id, i]));
    for (const raw of tail) {
      const incoming = conciseEntry(raw);
      const existingIndex = indexById.get(incoming.id);
      if (existingIndex !== undefined) {
        const existing = entries[existingIndex];
        if (existing && incoming.text.length >= existing.text.length) {
          entries[existingIndex] = incoming;
        }
      } else {
        indexById.set(incoming.id, entries.length);
        entries.push(incoming);
      }
    }
    return { ...buffer, entries };
  }
  function prependHistory(buffer, entries, truncated) {
    const known = new Set(buffer.entries.map((e) => e.id));
    const older = entries.filter((e) => !known.has(e.id)).map(conciseEntry);
    return { entries: [...older, ...buffer.entries], hasMore: truncated };
  }

  // src/core/live.ts
  class NoopLiveTail {
    start(_hostKey, _sessionId, _onEvent) {}
    stop() {}
  }
  function buildLiveWsUrl(hubUrl, hostKey, sessionId, token) {
    const wsBase = hubUrl.replace(/^https:\/\//i, "wss://").replace(/^http:\/\//i, "ws://").replace(/\/$/, "");
    return `${wsBase}/live/${encodeURIComponent(hostKey)}/${encodeURIComponent(sessionId)}` + `?auth=${encodeURIComponent(token)}`;
  }
  var DEFAULT_BACKOFF_MS = [1000, 2000, 4000, 8000, 15000];
  var TOKEN_SKEW_MS = 30000;

  class LiveTail {
    hubClient;
    hubUrl;
    wsCtor;
    backoffMs;
    now;
    setTimer;
    clearTimer;
    cachedToken = null;
    generation = 0;
    ws = null;
    reconnectTimer = null;
    attempt = 0;
    hostKey = "";
    sessionId = "";
    onEvent = null;
    constructor(opts) {
      this.hubClient = opts.hubClient;
      this.hubUrl = opts.hubUrl;
      this.wsCtor = opts.WebSocket ?? globalThis.WebSocket;
      this.backoffMs = opts.backoffMs ?? DEFAULT_BACKOFF_MS;
      this.now = opts.now ?? (() => Date.now());
      this.setTimer = opts.setTimer ?? ((cb, ms) => setTimeout(cb, ms));
      this.clearTimer = opts.clearTimer ?? ((t) => clearTimeout(t));
    }
    start(hostKey, sessionId, onEvent) {
      if (this.onEvent && this.hostKey === hostKey && this.sessionId === sessionId) {
        this.onEvent = onEvent;
        return;
      }
      this.teardown();
      this.hostKey = hostKey;
      this.sessionId = sessionId;
      this.onEvent = onEvent;
      this.attempt = 0;
      const gen = ++this.generation;
      this.connect(gen);
    }
    stop() {
      this.generation++;
      this.onEvent = null;
      this.teardown();
    }
    teardown() {
      if (this.reconnectTimer) {
        this.clearTimer(this.reconnectTimer);
        this.reconnectTimer = null;
      }
      const ws = this.ws;
      this.ws = null;
      if (ws) {
        try {
          ws.close();
        } catch {}
      }
    }
    async getToken() {
      const cached = this.cachedToken;
      if (cached && this.now() < cached.expiresAt - TOKEN_SKEW_MS)
        return cached.token;
      const res = await this.hubClient.wsToken();
      this.cachedToken = { token: res.token, expiresAt: this.now() + Math.max(0, res.expiresInSec) * 1000 };
      return res.token;
    }
    async connect(gen) {
      const Ctor = this.wsCtor;
      if (!Ctor)
        return;
      let token;
      try {
        token = await this.getToken();
      } catch {
        if (gen === this.generation)
          this.scheduleReconnect(gen);
        return;
      }
      if (gen !== this.generation)
        return;
      const url = buildLiveWsUrl(this.hubUrl, this.hostKey, this.sessionId, token);
      let ws;
      try {
        ws = new Ctor(url);
      } catch {
        this.scheduleReconnect(gen);
        return;
      }
      this.ws = ws;
      let opened = false;
      ws.addEventListener("open", () => {
        if (gen === this.generation) {
          this.attempt = 0;
          opened = true;
        }
      });
      ws.addEventListener("message", (ev) => {
        if (gen !== this.generation)
          return;
        if (typeof ev.data !== "string")
          return;
        let frame;
        try {
          frame = JSON.parse(ev.data);
        } catch {
          return;
        }
        if (frame?.type === "tail" && Array.isArray(frame.entries) && frame.entries.length) {
          this.onEvent?.({ type: "tail", entries: frame.entries });
        } else if (frame?.type === "turn" && typeof frame.text === "string") {
          this.onEvent?.({ type: "turn", text: frame.text });
        }
      });
      const onEnd = () => {
        if (gen !== this.generation)
          return;
        if (this.ws === ws)
          this.ws = null;
        if (!opened)
          this.cachedToken = null;
        this.scheduleReconnect(gen);
      };
      ws.addEventListener("close", onEnd);
      ws.addEventListener("error", onEnd);
    }
    scheduleReconnect(gen) {
      if (gen !== this.generation)
        return;
      if (this.reconnectTimer)
        return;
      const wait = this.backoffMs[Math.min(this.attempt, this.backoffMs.length - 1)] ?? 1000;
      this.attempt++;
      this.reconnectTimer = this.setTimer(() => {
        this.reconnectTimer = null;
        if (gen !== this.generation)
          return;
        this.connect(gen);
      }, wait);
    }
  }

  // src/core/reveal.ts
  var REVEAL_RATE_CPS = 150;
  var REVEAL_SNAP_CHARS = 200;
  function emptyReveal() {
    return { entryId: null, shown: 0 };
  }
  function fullReveal(entryId, len) {
    return { entryId, shown: entryId === null ? 0 : Math.max(0, len) };
  }
  function advanceReveal(prev, newestId, targetLen, dtMs, opts = {}) {
    if (newestId === null || targetLen <= 0) {
      return { entryId: newestId, shown: 0 };
    }
    const rate = opts.rateCps ?? REVEAL_RATE_CPS;
    const snap = opts.snapChars ?? REVEAL_SNAP_CHARS;
    const sameEntry = prev.entryId === newestId;
    if (!sameEntry && !opts.live)
      return { entryId: newestId, shown: targetLen };
    const base = sameEntry ? Math.min(prev.shown, targetLen) : 0;
    const backlog = targetLen - base;
    if (backlog <= 0)
      return { entryId: newestId, shown: targetLen };
    if (backlog > snap)
      return { entryId: newestId, shown: targetLen };
    const step = Math.floor(rate * Math.max(0, dtMs) / 1000);
    return { entryId: newestId, shown: Math.min(targetLen, base + step) };
  }
  function revealComplete(state, targetLen) {
    return state.entryId === null || targetLen <= 0 || state.shown >= targetLen;
  }

  // src/core/sessions.ts
  var WORKING_WINDOW_MS = 90 * 1000;
  function liveState(s) {
    if (s.status === "error")
      return "error";
    if (s.status === "stopped")
      return "stopped";
    if (s.status === "queued")
      return "queued";
    const live = s.session;
    if (live?.question)
      return "waiting";
    const working = live?.paneBusy != null ? live.paneBusy : live?.transcriptAgeSec != null && live.transcriptAgeSec * 1000 < WORKING_WINDOW_MS;
    return working ? "working" : "idle";
  }
  var GLYPHS = {
    working: "!",
    waiting: "?",
    idle: "-",
    stopped: "o",
    error: "x",
    pending: "…",
    queued: "…"
  };
  function glyph(state) {
    return GLYPHS[state];
  }
  function sessionName(s) {
    const summary = s.summary?.trim();
    return summary || s.id.slice(0, 6);
  }
  function siteKeyOf(agent) {
    return agent.jira && agent.jira.siteKey || "";
  }
  function filterAgents(agents, key) {
    if (!key)
      return agents;
    return agents.filter((a) => siteKeyOf(a) === key);
  }
  function flattenSessions(agents) {
    const hosts = [...agents].sort((a, b) => (a.device ?? a.key).localeCompare(b.device ?? b.key));
    const out = [];
    for (const agent of hosts) {
      const sessions = [...agent.sessions ?? []].sort((a, b) => (a.createdAt ?? "").localeCompare(b.createdAt ?? ""));
      for (const session of sessions) {
        out.push({ hostKey: agent.key, device: agent.device ?? agent.key, online: agent.online, session });
      }
    }
    return out;
  }

  // src/core/layout.ts
  var DISPLAY_LINES = 7;
  var LINE_WIDTH_PX = 560;

  // src/core/text-wrap.ts
  var PX_PER_CHAR = 560 / 55;
  function charMeasure(s) {
    return s.length * PX_PER_CHAR;
  }
  var defaultMeasure = charMeasure;
  var measureGen = 0;
  function setDefaultMeasure(measure) {
    defaultMeasure = measure;
    measureGen++;
  }
  function measureGeneration() {
    return measureGen;
  }
  function measureDefault(s) {
    return defaultMeasure(s);
  }
  var EPSILON = 0.000001;
  function fits(s, maxWidthPx, measure) {
    return measure(s) <= maxWidthPx + EPSILON;
  }
  function splitLongWord(word, maxWidthPx, measure) {
    const chunks = [];
    let remainder = word;
    while (remainder.length > 0 && !fits(remainder, maxWidthPx, measure)) {
      let splitAt = remainder.length;
      while (splitAt > 1 && !fits(remainder.slice(0, splitAt), maxWidthPx, measure)) {
        splitAt--;
      }
      chunks.push(remainder.slice(0, splitAt));
      remainder = remainder.slice(splitAt);
    }
    if (remainder.length > 0)
      chunks.push(remainder);
    return chunks;
  }
  function wrapText(text, maxWidthPx, measure = defaultMeasure) {
    if (!text.trim())
      return [];
    const lines = [];
    for (const paragraph of text.split(`
`)) {
      const words = paragraph.split(/\s+/).filter(Boolean);
      if (words.length === 0) {
        lines.push("");
        continue;
      }
      let current = "";
      for (const word of words) {
        const candidate = current ? `${current} ${word}` : word;
        if (fits(candidate, maxWidthPx, measure)) {
          current = candidate;
          continue;
        }
        if (current)
          lines.push(current);
        if (fits(word, maxWidthPx, measure)) {
          current = word;
        } else {
          const chunks = splitLongWord(word, maxWidthPx, measure);
          for (let i = 0;i < chunks.length - 1; i++)
            lines.push(chunks[i]);
          current = chunks[chunks.length - 1] ?? "";
        }
      }
      if (current)
        lines.push(current);
    }
    return lines;
  }

  // src/core/input-box.ts
  var BOTTOM_MAX_LINES = Math.floor(DISPLAY_LINES / 2);
  var MENU_MAX_LINES = DISPLAY_LINES - 2;
  function bottomBoxLines(contentLines) {
    return Math.max(1, Math.min(BOTTOM_MAX_LINES, contentLines.length));
  }
  function windowTail(lines, viewOffset) {
    const total = lines.length;
    const maxOffset = Math.max(0, total - BOTTOM_MAX_LINES);
    const offset = Math.max(0, Math.min(viewOffset, maxOffset));
    const end = total - offset;
    const start = Math.max(0, end - BOTTOM_MAX_LINES);
    return lines.slice(start, end);
  }
  function draftMaxViewOffset(text) {
    const wrapped = wrapText(text, LINE_WIDTH_PX);
    return Math.max(0, wrapped.length - BOTTOM_MAX_LINES);
  }
  function inputBoxBody(opts) {
    const { text, focused, mic, viewOffset } = opts;
    if (mic === "recording")
      return ["> Listening…"];
    if (mic === "finalising")
      return ["> Processing…"];
    if (text.length === 0)
      return focused ? ["> Tap to dictate…"] : [""];
    const prefix = focused ? "> " : "  ";
    const wrapped = wrapText(text, LINE_WIDTH_PX);
    const windowed = windowTail(wrapped, viewOffset);
    if (windowed.length === 0)
      return windowed;
    return [`${prefix}${windowed[0]}`, ...windowed.slice(1)];
  }
  function sheetBody(opts) {
    const { question, options } = opts;
    const rows = [...options.map((opt, i) => `${i + 1}. ${opt}`), `${options.length + 1}. Dictate answer…`];
    const total = rows.length;
    const selected = Math.max(0, Math.min(opts.selected, total - 1));
    const questionLines = wrapText(question, LINE_WIDTH_PX).slice(0, BOTTOM_MAX_LINES - 1);
    const area = BOTTOM_MAX_LINES - questionLines.length;
    let start = 0;
    if (total > area) {
      start = Math.max(0, selected - Math.floor(area / 2));
      start = Math.min(start, total - area);
    }
    const visibleRows = rows.slice(start, start + area).map((row, i) => start + i === selected ? `> ${row}` : `  ${row}`);
    return [...questionLines, ...visibleRows];
  }
  function statusLabel(opts) {
    switch (opts.mic) {
      case "recording":
        return "[REC]";
      case "finalising":
        return "[…]";
      case "error":
        return "[!]";
      case "idle":
        break;
    }
    switch (opts.live) {
      case "working":
        return "Working";
      case "waiting":
        return "Waiting";
      case "idle":
        return "Idle";
      case "stopped":
        return "Stopped";
      case "error":
        return "Error";
      case "queued":
        return "Queued";
    }
  }
  function menuBox(opts) {
    const { title, rows } = opts;
    const total = rows.length;
    const selected = Math.max(0, Math.min(opts.selected, total - 1));
    const titleLines = wrapText(title, LINE_WIDTH_PX).slice(0, MENU_MAX_LINES - 1);
    const area = MENU_MAX_LINES - titleLines.length;
    let start = 0;
    if (total > area) {
      start = Math.max(0, selected - Math.floor(area / 2));
      start = Math.min(start, total - area);
    }
    const visibleRows = rows.slice(start, start + area).map((row, i) => start + i === selected ? `> ${row}` : `  ${row}`);
    return [...titleLines, ...visibleRows];
  }

  // src/core/render.ts
  var SESSION_SCROLL_STEP = 2;
  var LIVE_TURN_ID = "__live";
  function linesModel(lines) {
    return { type: "lines", lines };
  }
  function wrap(text) {
    return wrapText(text, LINE_WIDTH_PX);
  }
  var CONTINUATION_INDENT = "  ";
  var contentWidthCache = null;
  function contentWidth() {
    const gen = measureGeneration();
    if (!contentWidthCache || contentWidthCache.gen !== gen) {
      contentWidthCache = { gen, width: LINE_WIDTH_PX - measureDefault(CONTINUATION_INDENT) };
    }
    return contentWidthCache.width;
  }
  var WRAP_CACHE_MAX = 512;
  var wrapCache = new Map;
  function wrapCached(text, width) {
    const key = `${measureGeneration()} ${width} ${text}`;
    const hit = wrapCache.get(key);
    if (hit) {
      wrapCache.delete(key);
      wrapCache.set(key, hit);
      return hit;
    }
    const lines = wrapText(text, width);
    wrapCache.set(key, lines);
    if (wrapCache.size > WRAP_CACHE_MAX) {
      const oldest = wrapCache.keys().next().value;
      if (oldest !== undefined)
        wrapCache.delete(oldest);
    }
    return lines;
  }
  function activeFlash(state) {
    return state.flash && state.now < state.flashUntil ? state.flash : null;
  }
  function headerLine(state, fallback) {
    return activeFlash(state) ?? fallback;
  }
  function findSessionLocal(state, hostKey, sessionId) {
    return state.agents.find((a) => a.key === hostKey)?.sessions.find((s) => s.id === sessionId);
  }
  function findAgentLocal(state, hostKey) {
    return state.agents.find((a) => a.key === hostKey);
  }
  function markerLine(text, selected) {
    return (selected ? "> " : "  ") + text;
  }
  function windowRows(rows, selectedIndex, area) {
    if (rows.length <= area)
      return { visible: rows, start: 0 };
    const selected = Math.max(0, Math.min(selectedIndex, rows.length - 1));
    let start = Math.max(0, selected - Math.floor(area / 2));
    start = Math.min(start, rows.length - area);
    return { visible: rows.slice(start, start + area), start };
  }
  function homeAgents(state) {
    return filterAgents(state.agents, state.orgFilter);
  }
  function homeHeaderText(state) {
    let working = 0;
    let waiting = 0;
    for (const agent of homeAgents(state)) {
      if (!agent.online)
        continue;
      for (const session of agent.sessions ?? []) {
        const s = liveState(session);
        if (s === "working")
          working++;
        else if (s === "waiting")
          waiting++;
      }
    }
    return `TURMA ${working} run · ${waiting} ask`;
  }
  function buildHomeRows(state) {
    const rows = [];
    const hosts = [...homeAgents(state)].sort((a, b) => (a.device ?? a.key).localeCompare(b.device ?? b.key));
    for (const agent of hosts) {
      const device = agent.device ?? agent.key;
      if (!agent.online) {
        rows.push({ kind: "hostOffline", hostKey: agent.key, selectable: false, text: `${device} offline` });
        continue;
      }
      rows.push({ kind: "hostHeader", hostKey: agent.key, selectable: false, text: device });
      const sessions = [...agent.sessions ?? []].sort((a, b) => (a.createdAt ?? "").localeCompare(b.createdAt ?? ""));
      for (const session of sessions) {
        const display = state.pending[session.id] ? "pending" : liveState(session);
        const g = glyph(display);
        const labelOrRepo = session.label || session.repo;
        const name = sessionName(session);
        rows.push({
          kind: "session",
          hostKey: agent.key,
          sessionId: session.id,
          selectable: true,
          text: `${g} ${labelOrRepo}-${name}`
        });
      }
    }
    rows.push({ kind: "newSession", selectable: true, text: "+ New session" });
    rows.push({ kind: "settings", selectable: true, text: "Settings" });
    return rows;
  }
  function renderHome(state) {
    const header = headerLine(state, homeHeaderText(state));
    const rows = buildHomeRows(state);
    const { visible, start } = windowRows(rows, state.home.cursor, DISPLAY_LINES - 1);
    const lines = [header];
    visible.forEach((row, i) => lines.push(markerLine(row.text, start + i === state.home.cursor)));
    return lines;
  }
  function roleMarker(role) {
    if (role === "user")
      return "» ";
    if (role === "assistant")
      return "· ";
    return `[${role}] `;
  }
  function roleBlock(role, text) {
    const marker = roleMarker(role);
    return wrapCached(text, contentWidth()).map((line, i) => i === 0 ? marker + line : CONTINUATION_INDENT + line);
  }
  function sessionContentLines(state, hostKey, sessionId) {
    const lines = [];
    const buffer = state.transcripts[sessionId];
    if (state.loadingHistory[sessionId]) {
      lines.push("· loading earlier ·");
    } else if (buffer?.hasMore === true) {
      lines.push("· earlier history truncated ·");
    }
    const entries = buffer?.entries ?? [];
    const reveal = state.session?.sessionId === sessionId ? state.reveal : null;
    const lastIdx = entries.length - 1;
    entries.forEach((entry, i) => {
      let text = entry.text;
      if (reveal && i === lastIdx && reveal.entryId === entry.id && reveal.shown < text.length) {
        text = text.slice(0, Math.max(0, reveal.shown));
      }
      if (text === "")
        return;
      lines.push(...roleBlock(entry.role, text));
    });
    const s = findSessionLocal(state, hostKey, sessionId);
    for (const url of s?.session?.newPrUrls ?? []) {
      lines.push(...wrapCached(`PR ${url}`, LINE_WIDTH_PX));
    }
    const lt = state.liveTurn;
    if (lt && lt.sessionId === sessionId && lt.text) {
      const reveal2 = state.session?.sessionId === sessionId ? state.reveal : null;
      let text = lt.text;
      if (reveal2 && reveal2.entryId === LIVE_TURN_ID && reveal2.shown < text.length) {
        text = text.slice(0, Math.max(0, reveal2.shown));
      }
      lines.push(...roleBlock("assistant", text));
    }
    return lines;
  }
  function questionSheetActive(question, sess) {
    return !!question && sess.mic === "idle" && sess.draft === "";
  }
  function renderSessionBottom(state, sess) {
    const s = findSessionLocal(state, sess.hostKey, sess.sessionId);
    const focus = sess.focus;
    const mic = sess.mic;
    const live = s ? liveState(s) : "idle";
    const status = statusLabel({ mic, live });
    const focused = focus === "bottom";
    const question = s?.session?.question;
    if (questionSheetActive(question, sess)) {
      const options = s?.session?.questionOptions ?? [];
      const selected = sess.selected;
      return { mode: "sheet", lines: sheetBody({ question, options, selected }), options, selected, status: "", focused };
    }
    const draft = sess.draft;
    const viewOffset = sess.viewOffset;
    const boxStatus = mic === "idle" && draft.length > 0 ? "" : status;
    return { mode: "input", lines: inputBoxBody({ text: draft, focused, mic, viewOffset }), status: boxStatus, focused };
  }
  function boxLineCount(bottom) {
    return bottom.mode === "menu" ? Math.max(1, bottom.lines.length) : bottomBoxLines(bottom.lines);
  }
  function sessionTranscriptArea(state, sess) {
    return DISPLAY_LINES - bottomBoxLines(renderSessionBottom(state, sess).lines);
  }
  function renderSession(state) {
    const sess = state.session;
    if (!sess) {
      return {
        type: "session",
        transcriptLines: [],
        bottom: {
          mode: "input",
          lines: inputBoxBody({ text: "", focused: false, mic: "idle", viewOffset: 0 }),
          status: statusLabel({ mic: "idle", live: "idle" }),
          focused: false
        }
      };
    }
    const bottom = renderSessionBottom(state, sess);
    const content = sessionContentLines(state, sess.hostKey, sess.sessionId);
    const flash = activeFlash(state);
    const flashLines = flash ? wrap(flash) : [];
    const area = Math.max(1, DISPLAY_LINES - bottomBoxLines(bottom.lines) - flashLines.length);
    const maxOffset = Math.max(0, content.length - area);
    const offset = Math.min(sess.offset, maxOffset);
    const end = content.length - offset;
    const start = Math.max(0, end - area);
    const transcriptLines = [...flashLines, ...content.slice(start, end)];
    return { type: "session", transcriptLines, bottom };
  }
  function buildActionsRows(state, hostKey, sessionId) {
    const s = findSessionLocal(state, hostKey, sessionId);
    if (!s || s.status === "stopped") {
      return [
        { action: "back", text: "Back" },
        { action: "start", text: "Start" }
      ];
    }
    const draft = state.session && state.session.hostKey === hostKey && state.session.sessionId === sessionId ? state.session.draft : "";
    const rows = [{ action: "back", text: "Back" }];
    if (draft) {
      rows.push({ action: "send", text: "Send" });
      rows.push({ action: "clear", text: "Clear" });
      rows.push({ action: "dictate", text: "Dictate more" });
    }
    rows.push({ action: "kill", text: "End this session" });
    return rows;
  }
  function sessionOverlay(state, hostKey, sessionId, bottom) {
    const content = sessionContentLines(state, hostKey, sessionId);
    const area = Math.max(1, DISPLAY_LINES - boxLineCount(bottom));
    const start = Math.max(0, content.length - area);
    return { type: "session", transcriptLines: content.slice(start), bottom };
  }
  function renderActions(state) {
    const a = state.actions;
    if (!a)
      return linesModel([headerLine(state, "Actions")]);
    const rows = buildActionsRows(state, a.hostKey, a.sessionId);
    const bottom = {
      mode: "menu",
      lines: menuBox({ title: "Options", rows: rows.map((r) => r.text), selected: a.cursor }),
      status: ""
    };
    return sessionOverlay(state, a.hostKey, a.sessionId, bottom);
  }
  function replyButtons(r) {
    return r.phase === "unavailable" ? ["Redo", "Cancel"] : ["Send", "Redo", "Cancel"];
  }
  function renderReply(state) {
    const r = state.reply;
    if (!r)
      return [headerLine(state, "Reply")];
    const header = headerLine(state, "Reply");
    if (r.phase === "listening") {
      return [header, "● listening… (tap=done)"];
    }
    const lines = [header];
    if (r.phase === "unavailable") {
      lines.push(...wrap(r.reason ?? "dictation unavailable"));
    } else {
      lines.push(...wrap(r.text));
      lines.push(`${r.text.length} chars`);
    }
    const buttons = replyButtons(r);
    buttons.forEach((text, i) => lines.push(markerLine(text, i === r.cursor)));
    return lines;
  }
  function confirmHeader(state) {
    const c = state.confirm;
    if (!c)
      return "Confirm";
    const s = findSessionLocal(state, c.action.hostKey, c.action.sessionId);
    const name = s ? sessionName(s) : c.action.sessionId.slice(0, 6);
    return `End session ${name}?`;
  }
  function renderConfirm(state) {
    const c = state.confirm;
    if (!c)
      return linesModel([headerLine(state, "Confirm")]);
    const bottom = {
      mode: "menu",
      lines: menuBox({ title: confirmHeader(state), rows: ["Cancel", "Confirm"], selected: c.cursor }),
      status: ""
    };
    return sessionOverlay(state, c.action.hostKey, c.action.sessionId, bottom);
  }
  function newHostRows(state) {
    return state.agents.filter((a) => a.online).map((a) => ({ hostKey: a.key, text: a.device ?? a.key }));
  }
  function renderNewHost(state) {
    const n = state.newHost;
    const header = headerLine(state, "New session · Choose host");
    const rows = newHostRows(state);
    if (!n)
      return [header];
    const { visible, start } = windowRows(rows, n.cursor, DISPLAY_LINES - 1);
    const lines = [header];
    visible.forEach((row, i) => lines.push(markerLine(row.text, start + i === n.cursor)));
    return lines;
  }
  function buildNewRepoRows(state, hostKey) {
    const agent = findAgentLocal(state, hostKey);
    if (!agent)
      return [];
    const rows = [];
    for (const repo of agent.repos ?? []) {
      rows.push({ kind: "repo", repo: repo.name, text: repo.isRoot ? "Repos root (all repos)" : repo.name });
    }
    return rows;
  }
  function renderNewRepo(state) {
    const n = state.newRepo;
    const device = n ? findAgentLocal(state, n.hostKey)?.device ?? n.hostKey : "";
    const header = headerLine(state, `New session · ${device} · Choose repo`);
    if (!n)
      return [header];
    const rows = buildNewRepoRows(state, n.hostKey);
    const { visible, start } = windowRows(rows, n.cursor, DISPLAY_LINES - 1);
    const lines = [header];
    visible.forEach((row, i) => lines.push(markerLine(row.text, start + i === n.cursor)));
    return lines;
  }
  function renderNewPrompt(state) {
    const n = state.newPrompt;
    const header = headerLine(state, "Dictate initial prompt?");
    if (!n)
      return [header];
    const rows = ["Dictate initial prompt…", "Skip (spawn now)"];
    const lines = [header];
    rows.forEach((text, i) => lines.push(markerLine(text, i === n.cursor)));
    return lines;
  }
  function renderSettings(state) {
    const header = headerLine(state, "Settings");
    const online = state.agents.filter((a) => a.online).length;
    const total = state.agents.length;
    return [header, `${online}/${total} hosts online`, "Configure on phone", markerLine("Back", true)];
  }
  function render(state) {
    switch (state.screen) {
      case "home":
        return linesModel(renderHome(state));
      case "session":
        return renderSession(state);
      case "actions":
        return renderActions(state);
      case "reply":
        return linesModel(renderReply(state));
      case "confirm":
        return renderConfirm(state);
      case "newHost":
        return linesModel(renderNewHost(state));
      case "newRepo":
        return linesModel(renderNewRepo(state));
      case "newPrompt":
        return linesModel(renderNewPrompt(state));
      case "settings":
        return linesModel(renderSettings(state));
    }
  }

  // src/core/app.ts
  var PENDING_TIMEOUT_MS = 60 * 1000;
  var POLL_GRACE_MS = 60 * 1000;
  var FLASH_DURATION_MS = 4000;
  var FLASH_QUEUED = "✓ queued — agent picks up in ~20s";
  var FLASH_HUB_UNREACHABLE = "hub unreachable";
  var HISTORY_RETRY_MS = 3000;
  var REVEAL_TICK_MS = 80;
  function pendingKeyForSpawn(hostKey, repo) {
    return `spawn:${hostKey}:${repo}`;
  }
  function newSessionState(hostKey, sessionId) {
    return { hostKey, sessionId, offset: 0, focus: "transcript", draft: "", mic: "idle", viewOffset: 0, selected: 0 };
  }
  function createInitialState(now) {
    return {
      now,
      screen: "home",
      flash: null,
      flashUntil: 0,
      pollErrorActive: false,
      agents: [],
      orgFilter: "",
      orgColors: {},
      autoStartOrgs: {},
      sessionRefs: [],
      transcripts: {},
      reveal: emptyReveal(),
      liveTurn: null,
      pending: {},
      loadingHistory: {},
      home: { cursor: 0 },
      session: null,
      actions: null,
      reply: null,
      confirm: null,
      newHost: null,
      newRepo: null,
      newPrompt: null,
      settings: null
    };
  }
  function findAgent(state, hostKey) {
    return state.agents.find((a) => a.key === hostKey);
  }
  function findSession(state, hostKey, sessionId) {
    return findAgent(state, hostKey)?.sessions.find((s) => s.id === sessionId);
  }

  class App {
    client;
    display;
    dictation;
    liveTail;
    now;
    pollMs;
    onEnterSession;
    onState;
    onRichTail;
    state;
    pollTimer = null;
    historyTimers = {};
    revealTimer = null;
    lastRevealAt = 0;
    paused = false;
    graceUntil = 0;
    constructor(opts) {
      this.client = opts.client;
      this.display = opts.display;
      this.dictation = opts.dictation;
      this.liveTail = opts.liveTail ?? new NoopLiveTail;
      this.now = opts.now ?? (() => Date.now());
      this.pollMs = opts.pollMs ?? 6000;
      this.onEnterSession = opts.onEnterSession;
      this.onState = opts.onState;
      this.onRichTail = opts.onRichTail;
      this.state = createInitialState(this.now());
    }
    getState() {
      return this.state;
    }
    async start() {
      const firstAgents = this.client.listAgents();
      firstAgents.catch(() => {});
      await this.display.start();
      this.display.onInput((e) => this.handleInput(e));
      this.schedulePoll(0, firstAgents);
    }
    pause(opts) {
      if (opts?.hard)
        this.graceUntil = 0;
      if (this.state.screen === "reply" && this.state.reply?.phase === "listening") {
        const r = this.state.reply;
        this.dictation.cancel();
        this.leaveReply(r);
      } else if (this.state.session && (this.state.session.mic === "recording" || this.state.session.mic === "finalising")) {
        this.dictation.cancel();
        this.setState({ session: { ...this.state.session, mic: "idle" } });
      }
      this.paused = true;
      if (this.pollTimer) {
        clearTimeout(this.pollTimer);
        this.pollTimer = null;
      }
      this.schedulePoll(this.pollMs);
      this.liveTail.stop();
      this.clearRevealTimer();
      if (this.state.liveTurn)
        this.state = { ...this.state, liveTurn: null };
      this.clearHistoryTimers();
      if (Object.keys(this.state.loadingHistory).length > 0) {
        this.state = { ...this.state, now: this.now(), loadingHistory: {} };
        this.repaint();
      }
    }
    resume() {
      if (!this.paused)
        return;
      this.paused = false;
      if (this.state.screen === "session" && this.state.session) {
        this.startLiveTail(this.state.session.hostKey, this.state.session.sessionId);
        this.reanchorReveal(this.state.session.sessionId);
        this.scheduleRevealTick();
      }
      this.schedulePoll(0);
    }
    restoreScreen(screen, session) {
      this.setState({ screen, session });
    }
    currentSessionId() {
      return this.state.screen === "session" ? this.state.session?.sessionId ?? null : null;
    }
    setOrgFilter(siteKey) {
      const next = siteKey || "";
      if (next === this.state.orgFilter)
        return;
      this.setState({ orgFilter: next, home: { cursor: 0 } });
    }
    setAutoStartOrg(siteKey, enabled) {
      const prev = !!this.state.autoStartOrgs[siteKey];
      if (prev === enabled)
        return prev;
      const next = { ...this.state.autoStartOrgs };
      if (enabled)
        next[siteKey] = true;
      else
        delete next[siteKey];
      this.setState({ autoStartOrgs: next });
      return prev;
    }
    enterSession(sessionId, hostKeyHint) {
      if (!sessionId)
        return;
      if (this.currentSessionId() === sessionId)
        return;
      const host = this.state.agents.find((a) => (a.sessions ?? []).some((s) => s.id === sessionId))?.key ?? hostKeyHint;
      if (!host)
        return;
      this.setState({ screen: "session", session: newSessionState(host, sessionId) });
    }
    schedulePoll(delayMs, prefetched) {
      if (this.paused && this.now() >= this.graceUntil)
        return;
      if (this.pollTimer)
        clearTimeout(this.pollTimer);
      this.pollTimer = setTimeout(() => {
        this.poll(prefetched);
      }, delayMs);
    }
    nudgePoll() {
      this.graceUntil = this.now() + POLL_GRACE_MS;
      this.schedulePoll(0);
    }
    setState(patch) {
      const prevScreen = this.state.screen;
      const prevSession = this.state.session;
      this.state = { ...this.state, ...patch, now: this.now() };
      if (prevScreen === "session" && prevSession && this.state.screen !== "session") {
        this.clearHistoryTimer(prevSession.sessionId);
        if (this.state.loadingHistory[prevSession.sessionId]) {
          this.state = {
            ...this.state,
            loadingHistory: { ...this.state.loadingHistory, [prevSession.sessionId]: false }
          };
        }
      }
      this.syncSession(prevScreen, prevSession);
      this.repaint();
    }
    syncSession(prevScreen, prevSession) {
      const cur = this.state.session;
      const inSession = this.state.screen === "session" && !!cur;
      const wasSession = prevScreen === "session" && !!prevSession;
      const same = inSession && wasSession && prevSession.sessionId === cur.sessionId && prevSession.hostKey === cur.hostKey;
      if (same)
        return;
      if (inSession) {
        this.onEnterSession?.(cur.hostKey, cur.sessionId);
        this.startLiveTail(cur.hostKey, cur.sessionId);
        const entries = this.state.transcripts[cur.sessionId]?.entries ?? [];
        const last = entries[entries.length - 1];
        this.state = {
          ...this.state,
          liveTurn: null,
          reveal: fullReveal(last?.id ?? null, last?.text.length ?? 0)
        };
        this.lastRevealAt = this.now();
      } else if (wasSession) {
        this.liveTail.stop();
        this.clearRevealTimer();
        this.state = { ...this.state, liveTurn: null, reveal: emptyReveal() };
      }
    }
    startLiveTail(hostKey, sessionId) {
      this.liveTail.start(hostKey, sessionId, (ev) => {
        if (ev.type === "tail")
          this.onLiveTail(hostKey, sessionId, ev.entries);
        else
          this.onLiveTurn(hostKey, sessionId, ev.text);
      });
    }
    onLiveTail(_hostKey, sessionId, entries) {
      if (this.state.screen !== "session" || this.state.session?.sessionId !== sessionId)
        return;
      this.onRichTail?.(sessionId, entries);
      const beforeLen = this.sessionContentLength(_hostKey, sessionId);
      const existing = this.state.transcripts[sessionId] ?? emptyBuffer();
      const merged = mergeTail(existing, entries);
      this.state = {
        ...this.state,
        now: this.now(),
        transcripts: { ...this.state.transcripts, [sessionId]: merged }
      };
      this.reanchorReveal(sessionId);
      this.preserveScrollOffset(beforeLen);
      this.repaint();
      this.scheduleRevealTick();
    }
    preserveScrollOffset(beforeLen) {
      const s = this.state.session;
      if (!s || s.offset <= 0)
        return;
      const afterLen = this.sessionContentLength(s.hostKey, s.sessionId);
      const growth = afterLen - beforeLen;
      if (growth > 0) {
        this.state = { ...this.state, session: { ...s, offset: s.offset + growth } };
      }
    }
    onLiveTurn(_hostKey, sessionId, text) {
      if (this.state.screen !== "session" || this.state.session?.sessionId !== sessionId)
        return;
      const beforeLen = this.sessionContentLength(_hostKey, sessionId);
      if (text) {
        this.state = { ...this.state, now: this.now(), liveTurn: { sessionId, text } };
        this.reanchorReveal(sessionId);
        this.preserveScrollOffset(beforeLen);
      } else {
        const entries = this.state.transcripts[sessionId]?.entries ?? [];
        const last = entries[entries.length - 1];
        this.state = {
          ...this.state,
          now: this.now(),
          liveTurn: null,
          reveal: fullReveal(last?.id ?? null, last?.text.length ?? 0)
        };
        this.lastRevealAt = this.now();
        this.preserveScrollOffset(beforeLen);
      }
      this.repaint();
      this.scheduleRevealTick();
    }
    newestRevealTarget(sessionId) {
      const lt = this.state.liveTurn;
      if (lt && lt.sessionId === sessionId && lt.text)
        return { id: LIVE_TURN_ID, len: lt.text.length, live: true };
      const entries = this.state.transcripts[sessionId]?.entries ?? [];
      const last = entries[entries.length - 1];
      return { id: last?.id ?? null, len: last?.text.length ?? 0, live: false };
    }
    repaint() {
      this.display.render(render(this.state));
      if (this.onState) {
        try {
          this.onState(this.state);
        } catch {}
      }
    }
    flash(text) {
      const now = this.now();
      this.state = { ...this.state, now, flash: text, flashUntil: now + FLASH_DURATION_MS };
    }
    clearRevealTimer() {
      if (this.revealTimer) {
        clearTimeout(this.revealTimer);
        this.revealTimer = null;
      }
    }
    reanchorReveal(sessionId) {
      if (this.state.session?.sessionId !== sessionId)
        return;
      const target = this.newestRevealTarget(sessionId);
      const reveal = advanceReveal(this.state.reveal, target.id, target.len, 0, { live: target.live });
      this.state = { ...this.state, reveal };
      this.lastRevealAt = this.now();
    }
    scheduleRevealTick() {
      if (this.paused || this.revealTimer)
        return;
      if (this.state.screen !== "session")
        return;
      if (this.state.session && this.state.session.offset > 0)
        return;
      this.revealTimer = setTimeout(() => {
        this.revealTimer = null;
        this.revealTick();
      }, REVEAL_TICK_MS);
    }
    revealTick() {
      const s = this.state.session;
      if (this.state.screen !== "session" || !s)
        return;
      if (s.offset > 0)
        return;
      const target = this.newestRevealTarget(s.sessionId);
      const targetLen = target.len;
      const now = this.now();
      const dt = now - this.lastRevealAt;
      this.lastRevealAt = now;
      const reveal = advanceReveal(this.state.reveal, target.id, targetLen, dt, { live: target.live });
      this.state = { ...this.state, now, reveal };
      this.repaint();
      if (!revealComplete(reveal, targetLen))
        this.scheduleRevealTick();
    }
    async poll(prefetched) {
      const now = this.now();
      try {
        const res = await (prefetched ?? this.client.listAgents());
        const sessionRefs = flattenSessions(res.agents);
        const focused = this.state.screen === "session" ? this.state.session : null;
        const beforeLen = focused ? this.sessionContentLength(focused.hostKey, focused.sessionId) : 0;
        const transcripts = { ...this.state.transcripts };
        for (const ref of sessionRefs) {
          const tail = ref.session.session?.tail ?? [];
          if (tail.length === 0)
            continue;
          const existing = transcripts[ref.session.id] ?? emptyBuffer();
          transcripts[ref.session.id] = mergeTail(existing, tail);
        }
        const pending = this.reconcilePending(this.state.pending, res.agents, sessionRefs, now);
        const wasErroring = this.state.pollErrorActive;
        const prevSession = this.state.session;
        const prevQuestion = prevSession ? findSession(this.state, prevSession.hostKey, prevSession.sessionId)?.session?.question ?? null : null;
        this.state = {
          ...this.state,
          now,
          agents: res.agents,
          orgColors: res.orgColors ?? {},
          autoStartOrgs: res.autoStartOrgs ?? {},
          sessionRefs,
          transcripts,
          pending,
          pollErrorActive: false,
          flash: wasErroring ? null : this.state.flash,
          flashUntil: wasErroring ? 0 : this.state.flashUntil
        };
        this.state = { ...this.state, home: { cursor: clampHomeCursor(this.homeRows(), this.state.home.cursor) } };
        if (!this.paused && this.state.screen === "session" && this.state.session) {
          this.reanchorReveal(this.state.session.sessionId);
          this.preserveScrollOffset(beforeLen);
          this.scheduleRevealTick();
        }
        if (this.state.session) {
          const sess = this.state.session;
          const live = findSession(this.state, sess.hostKey, sess.sessionId);
          const nowQuestion = live?.session?.question ?? null;
          if (nowQuestion && !prevQuestion) {
            if (sess.mic === "recording" || sess.mic === "finalising")
              this.dictation.cancel();
            const mic = sess.mic === "recording" || sess.mic === "finalising" ? "idle" : sess.mic;
            this.state = { ...this.state, session: { ...sess, mic, selected: 0 } };
          } else if (nowQuestion && prevQuestion && nowQuestion !== prevQuestion) {
            this.state = { ...this.state, session: { ...sess, selected: 0 } };
          }
        }
        this.repaint();
      } catch {
        if (!this.state.pollErrorActive) {
          this.state = { ...this.state, now, pollErrorActive: true };
          this.flash(FLASH_HUB_UNREACHABLE);
        } else {
          this.state = { ...this.state, now };
        }
        this.repaint();
      } finally {
        this.schedulePoll(this.pollMs);
      }
    }
    reconcilePending(pending, agents, sessionRefs, now) {
      const next = {};
      for (const [key, entry] of Object.entries(pending)) {
        if (now - entry.at >= PENDING_TIMEOUT_MS)
          continue;
        if (key.startsWith("spawn:")) {
          const [, hostKey, repo] = key.split(":");
          const count = agents.find((a) => a.key === hostKey)?.sessions.filter((s2) => s2.repo === repo).length ?? 0;
          if (entry.sessionCount != null && count > entry.sessionCount)
            continue;
          next[key] = entry;
          continue;
        }
        const ref = sessionRefs.find((r) => r.session.id === key);
        if (!ref) {
          next[key] = entry;
          continue;
        }
        const s = ref.session;
        const tailLen = s.session?.tail.length ?? 0;
        const converged = entry.status !== undefined && entry.status !== s.status || entry.question !== undefined && entry.question !== (s.session?.question ?? null) || entry.tailLen !== undefined && entry.tailLen !== tailLen;
        if (converged)
          continue;
        next[key] = entry;
      }
      return next;
    }
    markPending(sessionId, s) {
      const entry = {
        at: this.now(),
        status: s?.status,
        question: s?.session?.question ?? null,
        tailLen: s?.session?.tail.length ?? 0
      };
      this.state = { ...this.state, pending: { ...this.state.pending, [sessionId]: entry } };
    }
    markSpawnPending(hostKey, repo) {
      const count = findAgent(this.state, hostKey)?.sessions.filter((s) => s.repo === repo).length ?? 0;
      const key = pendingKeyForSpawn(hostKey, repo);
      const entry = { at: this.now(), sessionCount: count };
      this.state = { ...this.state, pending: { ...this.state.pending, [key]: entry } };
    }
    handleInput(e) {
      switch (this.state.screen) {
        case "home":
          return this.onHome(e);
        case "session":
          return this.onSession(e);
        case "actions":
          return this.onActions(e);
        case "reply":
          return this.onReply(e);
        case "confirm":
          return this.onConfirm(e);
        case "newHost":
          return this.onNewHost(e);
        case "newRepo":
          return this.onNewRepo(e);
        case "newPrompt":
          return this.onNewPrompt(e);
        case "settings":
          return this.onSettings(e);
      }
    }
    goHome() {
      this.setState({ screen: "home" });
    }
    homeRows() {
      return buildHomeRows(this.state);
    }
    onHome(e) {
      const rows = this.homeRows();
      const cursor = clampHomeCursor(rows, this.state.home.cursor);
      if (cursor !== this.state.home.cursor) {
        this.state = { ...this.state, home: { cursor } };
      }
      if (e.type === "doubleTap") {
        this.display.requestExit();
        return;
      }
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        const next = nextSelectableIndex(rows, cursor, dir);
        this.setState({ home: { cursor: next } });
        return;
      }
      if (e.type === "tap") {
        const row = rows[cursor];
        if (!row || !row.selectable)
          return;
        if (row.kind === "session" && row.hostKey && row.sessionId) {
          this.setState({
            screen: "session",
            session: newSessionState(row.hostKey, row.sessionId)
          });
        } else if (row.kind === "newSession") {
          this.setState({ screen: "newHost", newHost: { cursor: 0 } });
        } else if (row.kind === "settings") {
          this.setState({ screen: "settings", settings: { cursor: 0 } });
        }
      }
    }
    sessionContentLength(hostKey, sessionId) {
      const lines = sessionContentLines(this.state, hostKey, sessionId);
      return lines.length;
    }
    onSession(e) {
      const s = this.state.session;
      if (!s)
        return this.goHome();
      const live = findSession(this.state, s.hostKey, s.sessionId);
      if (questionSheetActive(live?.session?.question, s)) {
        return this.onSheetBottom(e, s, live);
      }
      if (s.focus === "bottom")
        return this.onSessionBottom(e, s);
      if (e.type === "doubleTap")
        return this.goHome();
      const area = sessionTranscriptArea(this.state, s);
      const total = this.sessionContentLength(s.hostKey, s.sessionId);
      const maxOffset = Math.max(0, total - area);
      if (e.type === "scrollDown") {
        const offset = Math.max(0, s.offset - SESSION_SCROLL_STEP);
        this.setState({ session: { ...s, offset } });
        if (offset === 0)
          this.resumeRevealAtTail(s.sessionId);
        return;
      }
      if (e.type === "scrollUp") {
        if (s.offset >= maxOffset) {
          const buffer = this.state.transcripts[s.sessionId];
          if (buffer?.hasMore === undefined) {
            this.triggerHistoryLoad(s.hostKey, s.sessionId);
            return;
          }
          return;
        }
        this.setState({ session: { ...s, offset: Math.min(maxOffset, s.offset + SESSION_SCROLL_STEP) } });
        return;
      }
      if (e.type === "tap") {
        if (s.offset > 0) {
          this.setState({ session: { ...s, offset: 0 } });
          this.resumeRevealAtTail(s.sessionId);
        } else {
          this.setState({ session: { ...s, focus: "bottom" } });
        }
      }
    }
    resumeRevealAtTail(sessionId) {
      this.reanchorReveal(sessionId);
      this.scheduleRevealTick();
    }
    onSessionBottom(e, s) {
      const live = findSession(this.state, s.hostKey, s.sessionId);
      if (questionSheetActive(live?.session?.question, s)) {
        return this.onSheetBottom(e, s, live);
      }
      if (e.type === "doubleTap") {
        this.cancelBoxDictation(s);
        this.setState({
          screen: "actions",
          session: { ...s, mic: "idle" },
          actions: { hostKey: s.hostKey, sessionId: s.sessionId, cursor: 0 }
        });
        return;
      }
      if (e.type === "tap") {
        if (s.mic === "idle" && s.draft) {
          this.setState({
            screen: "actions",
            actions: { hostKey: s.hostKey, sessionId: s.sessionId, cursor: 0 }
          });
          return;
        }
        this.toggleBoxDictation(s);
        return;
      }
      if (e.type === "scrollUp" || e.type === "scrollDown") {
        this.scrollInputBox(e.type, s);
      }
    }
    onSheetBottom(e, s, live) {
      const options = live?.session?.questionOptions ?? [];
      if (e.type === "doubleTap") {
        this.cancelBoxDictation(s);
        this.setState({
          screen: "actions",
          session: { ...s, mic: "idle" },
          actions: { hostKey: s.hostKey, sessionId: s.sessionId, cursor: 0 }
        });
        return;
      }
      if (e.type === "scrollUp" || e.type === "scrollDown") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        const selected = clamp(s.selected + dir, 0, options.length);
        this.setState({ session: { ...s, selected } });
        return;
      }
      if (e.type === "tap") {
        if (s.selected < options.length) {
          this.markPending(s.sessionId, live);
          this.client.answerQuestion(s.hostKey, s.sessionId, { optionIndex: s.selected }).then(() => {
            this.flash(FLASH_QUEUED);
            this.repaint();
          }).catch(() => {
            this.flash(FLASH_HUB_UNREACHABLE);
            this.repaint();
          });
          this.setState({ session: { ...s, focus: "transcript" } });
          return;
        }
        this.toggleBoxDictation({ ...s, focus: "bottom" });
      }
    }
    cancelBoxDictation(s) {
      if (s.mic === "recording" || s.mic === "finalising")
        this.dictation.cancel();
    }
    toggleBoxDictation(s) {
      if (s.mic === "idle") {
        const { hostKey, sessionId } = s;
        this.setState({ session: { ...s, mic: "recording" } });
        this.dictation.start((r) => this.onBoxDictationResult(r, hostKey, sessionId));
        return;
      }
      if (s.mic === "recording") {
        this.setState({ session: { ...s, mic: "finalising" } });
        this.dictation.stop();
      }
    }
    onBoxDictationResult(result, hostKey, sessionId) {
      const s = this.state.session;
      if (!s || s.hostKey !== hostKey || s.sessionId !== sessionId)
        return;
      if (result.unavailable) {
        this.setState({ session: { ...s, mic: "error" } });
        this.flash(result.reason ?? "dictation unavailable");
        this.setState({ session: { ...s, mic: "idle" } });
        return;
      }
      const draft = s.draft ? `${s.draft} ${result.text}` : result.text;
      this.setState({ session: { ...s, draft, mic: "idle", viewOffset: 0 } });
    }
    scrollInputBox(type, s) {
      if (s.draft === "")
        return this.handBackToTranscript(s);
      if (type === "scrollDown") {
        if (s.viewOffset <= 0)
          return this.handBackToTranscript(s);
        this.setState({ session: { ...s, viewOffset: s.viewOffset - 1 } });
        return;
      }
      const maxOffset = draftMaxViewOffset(s.draft);
      if (s.viewOffset >= maxOffset)
        return this.handBackToTranscript(s);
      this.setState({ session: { ...s, viewOffset: s.viewOffset + 1 } });
    }
    handBackToTranscript(s) {
      this.cancelBoxDictation(s);
      this.setState({ session: { ...s, focus: "transcript", mic: "idle" } });
    }
    clearHistoryTimer(sessionId) {
      const timer = this.historyTimers[sessionId];
      if (timer === undefined)
        return;
      clearTimeout(timer);
      delete this.historyTimers[sessionId];
    }
    clearHistoryTimers() {
      for (const timer of Object.values(this.historyTimers))
        clearTimeout(timer);
      this.historyTimers = {};
    }
    triggerHistoryLoad(hostKey, sessionId) {
      if (this.state.loadingHistory[sessionId])
        return;
      const bumpedSession = this.state.session && this.state.session.sessionId === sessionId ? { ...this.state.session, offset: this.state.session.offset + 1 } : this.state.session;
      this.setState({ loadingHistory: { ...this.state.loadingHistory, [sessionId]: true }, session: bumpedSession });
      this.pollHistory(hostKey, sessionId, this.now());
    }
    async pollHistory(hostKey, sessionId, startedAt) {
      try {
        const res = await this.client.getHistory(hostKey, sessionId);
        if (res.status === 202) {
          delete this.historyTimers[sessionId];
          if (this.now() - startedAt >= PENDING_TIMEOUT_MS) {
            this.state = {
              ...this.state,
              now: this.now(),
              loadingHistory: { ...this.state.loadingHistory, [sessionId]: false }
            };
            this.repaint();
            return;
          }
          this.historyTimers[sessionId] = setTimeout(() => {
            delete this.historyTimers[sessionId];
            this.pollHistory(hostKey, sessionId, startedAt);
          }, HISTORY_RETRY_MS);
          return;
        }
        const existing = this.state.transcripts[sessionId] ?? emptyBuffer();
        const merged = prependHistory(existing, res.body.entries, res.body.truncated);
        this.state = {
          ...this.state,
          now: this.now(),
          transcripts: { ...this.state.transcripts, [sessionId]: merged },
          loadingHistory: { ...this.state.loadingHistory, [sessionId]: false }
        };
        this.repaint();
      } catch {
        this.state = {
          ...this.state,
          now: this.now(),
          loadingHistory: { ...this.state.loadingHistory, [sessionId]: false }
        };
        this.repaint();
      }
    }
    onActions(e) {
      const a = this.state.actions;
      if (!a)
        return this.goHome();
      if (e.type === "doubleTap") {
        this.setState({ screen: "session", session: this.returnToSession(a.hostKey, a.sessionId) });
        return;
      }
      const rows = buildActionsRows(this.state, a.hostKey, a.sessionId);
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        const cursor = clamp(a.cursor + dir, 0, rows.length - 1);
        this.setState({ actions: { ...a, cursor } });
        return;
      }
      if (e.type === "tap") {
        const row = rows[a.cursor];
        if (!row)
          return;
        this.runAction(a.hostKey, a.sessionId, row.action);
      }
    }
    runAction(hostKey, sessionId, action) {
      switch (action) {
        case "send": {
          const sess = this.state.session;
          const draft = sess && sess.hostKey === hostKey && sess.sessionId === sessionId ? sess.draft : "";
          const s = findSession(this.state, hostKey, sessionId);
          this.markPending(sessionId, s);
          this.submitText(hostKey, sessionId, draft).then(() => {
            this.flash(FLASH_QUEUED);
            this.repaint();
          }).catch(() => {
            this.flash(FLASH_HUB_UNREACHABLE);
            this.repaint();
          });
          this.setState({ screen: "session", session: newSessionState(hostKey, sessionId) });
          return;
        }
        case "clear":
          this.setState({ screen: "session", session: newSessionState(hostKey, sessionId) });
          return;
        case "dictate": {
          const s = { ...this.returnToSession(hostKey, sessionId), focus: "bottom" };
          this.setState({ screen: "session", session: s });
          this.toggleBoxDictation(s);
          return;
        }
        case "start":
          this.queueAction(hostKey, sessionId, "start");
          return;
        case "kill":
          this.setState({ screen: "confirm", confirm: { action: { kind: "kill", hostKey, sessionId }, cursor: 0 } });
          return;
        case "back":
          this.setState({ screen: "session", session: this.returnToSession(hostKey, sessionId) });
          return;
      }
    }
    returnToSession(hostKey, sessionId) {
      const s = this.state.session;
      if (s && s.hostKey === hostKey && s.sessionId === sessionId)
        return s;
      return newSessionState(hostKey, sessionId);
    }
    queueAction(hostKey, sessionId, action) {
      const s = findSession(this.state, hostKey, sessionId);
      this.markPending(sessionId, s);
      this.client.sessionAction(hostKey, sessionId, action).then(() => {
        this.flash(FLASH_QUEUED);
        this.nudgePoll();
        this.repaint();
      }).catch(() => {
        this.flash(FLASH_HUB_UNREACHABLE);
        this.repaint();
      });
      this.setState({ screen: "session", session: newSessionState(hostKey, sessionId) });
    }
    startDictation() {
      this.dictation.start((result) => this.onDictationResult(result));
    }
    onDictationResult(result) {
      const r = this.state.reply;
      if (!r)
        return;
      if (result.unavailable) {
        this.setState({ reply: { ...r, phase: "unavailable", reason: result.reason, cursor: 0 } });
        return;
      }
      this.setState({ reply: { ...r, phase: "preview", text: result.text, cursor: 0 } });
    }
    onReply(e) {
      const r = this.state.reply;
      if (!r)
        return this.goHome();
      if (r.phase === "listening") {
        if (e.type === "tap") {
          this.dictation.stop();
          return;
        }
        if (e.type === "doubleTap") {
          this.dictation.cancel();
          this.leaveReply(r);
        }
        return;
      }
      const buttons = r.phase === "unavailable" ? ["redo", "cancel"] : ["send", "redo", "cancel"];
      if (e.type === "doubleTap") {
        this.leaveReply(r);
        return;
      }
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        this.setState({ reply: { ...r, cursor: clamp(r.cursor + dir, 0, buttons.length - 1) } });
        return;
      }
      if (e.type === "tap") {
        const button = buttons[r.cursor];
        if (button === "send") {
          this.sendReply(r);
        } else if (button === "redo") {
          this.setState({ reply: { ...r, phase: "listening", text: "", cursor: 0 } });
          this.startDictation();
        } else {
          this.leaveReply(r);
        }
      }
    }
    leaveReply(r) {
      if (r.target.kind === "session") {
        this.setState({
          screen: r.target.back,
          session: newSessionState(r.target.hostKey, r.target.sessionId)
        });
      } else {
        this.setState({
          screen: "newPrompt",
          newPrompt: { hostKey: r.target.hostKey, repo: r.target.repo, cursor: 0 }
        });
      }
    }
    submitText(hostKey, sessionId, text) {
      const s = findSession(this.state, hostKey, sessionId);
      if (s?.session?.question) {
        return this.client.answerQuestion(hostKey, sessionId, { optionIndex: -1, custom: text });
      }
      return this.client.sendInput(hostKey, sessionId, text);
    }
    sendReply(r) {
      if (r.target.kind === "session") {
        const { hostKey: hostKey2, sessionId } = r.target;
        const s = findSession(this.state, hostKey2, sessionId);
        this.markPending(sessionId, s);
        this.submitText(hostKey2, sessionId, r.text).then(() => {
          this.flash(FLASH_QUEUED);
          this.repaint();
        }).catch(() => {
          this.flash(FLASH_HUB_UNREACHABLE);
          this.repaint();
        });
        this.setState({ screen: "session", session: newSessionState(hostKey2, sessionId) });
        return;
      }
      const { hostKey, repo, label, baseRef, model, permissionMode } = r.target;
      this.markSpawnPending(hostKey, repo);
      this.client.spawnSession(hostKey, { repo, prompt: r.text, label, baseRef, model, permissionMode }).then(() => {
        this.flash(FLASH_QUEUED);
        this.nudgePoll();
        this.repaint();
      }).catch(() => {
        this.flash(FLASH_HUB_UNREACHABLE);
        this.repaint();
      });
      this.goHome();
    }
    onConfirm(e) {
      const c = this.state.confirm;
      if (!c)
        return this.goHome();
      if (e.type === "doubleTap") {
        this.setState({
          screen: "actions",
          actions: { hostKey: c.action.hostKey, sessionId: c.action.sessionId, cursor: 0 }
        });
        return;
      }
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        this.setState({ confirm: { ...c, cursor: c.cursor === 0 ? 1 : 0 } });
        return;
      }
      if (e.type === "tap") {
        if (c.cursor === 0) {
          this.setState({
            screen: "actions",
            actions: { hostKey: c.action.hostKey, sessionId: c.action.sessionId, cursor: 0 }
          });
          return;
        }
        const { hostKey, sessionId } = c.action;
        this.queueAction(hostKey, sessionId, "kill");
      }
    }
    onlineHosts() {
      return this.state.agents.filter((a) => a.online);
    }
    onNewHost(e) {
      const n = this.state.newHost;
      if (!n)
        return this.goHome();
      if (e.type === "doubleTap")
        return this.goHome();
      const hosts = this.onlineHosts();
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        this.setState({ newHost: { cursor: clamp(n.cursor + dir, 0, Math.max(0, hosts.length - 1)) } });
        return;
      }
      if (e.type === "tap") {
        const host = hosts[n.cursor];
        if (!host)
          return;
        this.setState({ screen: "newRepo", newRepo: { hostKey: host.key, cursor: 0 } });
      }
    }
    onNewRepo(e) {
      const n = this.state.newRepo;
      if (!n)
        return this.goHome();
      if (e.type === "doubleTap") {
        this.setState({ screen: "newHost", newHost: { cursor: 0 } });
        return;
      }
      const rows = buildNewRepoRows(this.state, n.hostKey);
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        this.setState({ newRepo: { ...n, cursor: clamp(n.cursor + dir, 0, Math.max(0, rows.length - 1)) } });
        return;
      }
      if (e.type === "tap") {
        const row = rows[n.cursor];
        if (!row)
          return;
        this.setState({
          screen: "newPrompt",
          newPrompt: { hostKey: n.hostKey, repo: row.repo, cursor: 0 }
        });
      }
    }
    onNewPrompt(e) {
      const n = this.state.newPrompt;
      if (!n)
        return this.goHome();
      if (e.type === "doubleTap") {
        this.setState({ screen: "newRepo", newRepo: { hostKey: n.hostKey, cursor: 0 } });
        return;
      }
      if (e.type === "scrollDown" || e.type === "scrollUp") {
        const dir = e.type === "scrollDown" ? 1 : -1;
        this.setState({ newPrompt: { ...n, cursor: clamp(n.cursor + dir, 0, 1) } });
        return;
      }
      if (e.type === "tap") {
        if (n.cursor === 0) {
          this.setState({
            screen: "reply",
            reply: {
              target: { kind: "spawn", hostKey: n.hostKey, repo: n.repo },
              phase: "listening",
              text: "",
              cursor: 0
            }
          });
          this.startDictation();
        } else {
          this.markSpawnPending(n.hostKey, n.repo);
          this.client.spawnSession(n.hostKey, { repo: n.repo }).then(() => {
            this.flash(FLASH_QUEUED);
            this.nudgePoll();
            this.repaint();
          }).catch(() => {
            this.flash(FLASH_HUB_UNREACHABLE);
            this.repaint();
          });
          this.goHome();
        }
      }
    }
    onSettings(e) {
      if (e.type === "doubleTap" || e.type === "tap") {
        this.goHome();
      }
    }
  }
  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }
  function nextSelectableIndex(rows, from, dir) {
    let i = from;
    for (let steps = 0;steps < rows.length; steps++) {
      const next = i + dir;
      if (next < 0 || next >= rows.length)
        break;
      i = next;
      if (rows[i]?.selectable)
        return i;
    }
    return from;
  }
  function clampHomeCursor(rows, cursor) {
    if (rows.length === 0)
      return 0;
    const c = clamp(cursor, 0, rows.length - 1);
    if (rows[c]?.selectable)
      return c;
    for (let d = 1;d < rows.length; d++) {
      const forward = c + d;
      if (forward < rows.length && rows[forward]?.selectable)
        return forward;
      const backward = c - d;
      if (backward >= 0 && rows[backward]?.selectable)
        return backward;
    }
    return c;
  }

  // src/core/config.ts
  var DEFAULT_POLL_MS = 6000;
  var CONFIG_STORAGE_KEY = "turma.glasses.config";
  var LEGACY_CONFIG_STORAGE_KEY = "agenthub.glasses.config";
  function normalizeHubUrl(raw) {
    const s = (raw ?? "").trim();
    if (!s)
      return "";
    const withScheme = /^https?:\/\//i.test(s) ? s : `https://${s}`;
    return withScheme.replace(/\/+$/, "");
  }
  function resolveHubUrl() {
    return "";
  }
  function envDefaults() {
    return {
      hubUrl: resolveHubUrl(),
      user: "",
      password: ""
    };
  }
  function emptyConfig() {
    const env = envDefaults();
    return {
      hubUrl: env.hubUrl ?? "",
      user: env.user ?? "",
      password: env.password ?? "",
      pollMs: DEFAULT_POLL_MS
    };
  }
  function isConfigured(config) {
    return Boolean(config.hubUrl && config.user && config.password);
  }
  async function loadConfig(storage) {
    const base = emptyConfig();
    let raw = await storage.get(CONFIG_STORAGE_KEY);
    if (!raw) {
      const legacy = await storage.get(LEGACY_CONFIG_STORAGE_KEY);
      if (legacy) {
        raw = legacy;
        await storage.set(CONFIG_STORAGE_KEY, legacy);
      }
    }
    if (!raw)
      return base;
    try {
      const parsed = JSON.parse(raw);
      const storedUrl = typeof parsed.hubUrl === "string" ? normalizeHubUrl(parsed.hubUrl) : "";
      return {
        hubUrl: base.hubUrl || storedUrl,
        user: typeof parsed.user === "string" ? parsed.user : base.user,
        password: typeof parsed.password === "string" ? parsed.password : base.password,
        pollMs: typeof parsed.pollMs === "number" && parsed.pollMs > 0 ? parsed.pollMs : base.pollMs
      };
    } catch {
      return base;
    }
  }
  function authHeader(config) {
    return "Basic " + btoa(`${config.user}:${config.password}`);
  }

  // src/core/hub-client.ts
  class HttpError extends Error {
    status;
    constructor(status, message) {
      super(message);
      this.name = "HttpError";
      this.status = status;
    }
  }

  class HubClient {
    config;
    fetchFn;
    constructor({ config, fetchFn }) {
      this.config = config;
      this.fetchFn = fetchFn ?? globalThis.fetch.bind(globalThis);
    }
    url(path) {
      return `${this.hubBase()}${path}`;
    }
    hubBase() {
      return this.config.hubUrl.replace(/\/$/, "");
    }
    termUrl(sessionId) {
      return `${this.hubBase()}/term/${encodeURIComponent(sessionId)}/`;
    }
    async loginForCookie() {
      try {
        await this.fetchFn(this.url("/api/login"), {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: this.config.user, password: this.config.password })
        });
      } catch {}
    }
    headers(extra) {
      return { Authorization: authHeader(this.config), ...extra };
    }
    async request(path, init = {}) {
      const res = await this.fetchFn(this.url(path), {
        ...init,
        headers: { ...this.headers(), ...init.headers }
      });
      if (!res.ok) {
        throw new HttpError(res.status, `hub request failed: ${res.status} ${path}`);
      }
      return await res.json();
    }
    listAgents() {
      return this.request("/api/agents");
    }
    spawnSession(host, opts) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(opts)
      });
    }
    sessionAction(host, id, action) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/${action}`, { method: "POST" });
    }
    deleteSession(host, id) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}`, { method: "DELETE" });
    }
    sendInput(host, id, text) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/input`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
    }
    answerQuestion(host, id, answer) {
      const body = {
        optionIndex: Number.isInteger(answer.optionIndex) ? answer.optionIndex : -1
      };
      if (answer.custom)
        body.custom = answer.custom;
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
    }
    async getHistory(host, id) {
      const path = `/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/history`;
      const res = await this.fetchFn(this.url(path), { headers: this.headers() });
      if (!res.ok) {
        throw new HttpError(res.status, `hub request failed: ${res.status} ${path}`);
      }
      const body = await res.json();
      if (res.status === 202)
        return { status: 202, body };
      return { status: 200, body };
    }
    wsToken() {
      return this.request("/api/ws-token");
    }
    async jiraDetail(siteKey, key) {
      const path = `/api/jira/${encodeURIComponent(siteKey)}/${encodeURIComponent(key)}`;
      const res = await this.fetchFn(this.url(path), { headers: this.headers() });
      if (!res.ok)
        throw new HttpError(res.status, `hub request failed: ${res.status} ${path}`);
      const body = await res.json();
      return res.status === 202 ? { status: 202, body } : { status: 200, body };
    }
    jiraPost(siteKey, key, action, body) {
      return this.request(`/api/jira/${encodeURIComponent(siteKey)}/${encodeURIComponent(key)}/${action}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    }
    startTicket(siteKey, key) {
      return this.request(`/api/jira/${encodeURIComponent(siteKey)}/${encodeURIComponent(key)}/session`, { method: "POST" });
    }
    setTicketStatus(siteKey, key, body) {
      return this.jiraPost(siteKey, key, "status", body);
    }
    setTicketRepo(siteKey, key, body) {
      return this.jiraPost(siteKey, key, "repo", body);
    }
    setTicketAgent(siteKey, key, body) {
      return this.jiraPost(siteKey, key, "agent", body);
    }
    setTicketModel(siteKey, key, body) {
      return this.jiraPost(siteKey, key, "model", body);
    }
    jiraRefresh() {
      return this.request("/api/jira/refresh", { method: "POST" });
    }
    setAutoStart(siteKey, enabled) {
      return this.request(`/api/jira/${encodeURIComponent(siteKey)}/autostart`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled })
      });
    }
    async createMeta(siteKey, project) {
      const q = project ? `?project=${encodeURIComponent(project)}` : "";
      const path = `/api/jira/${encodeURIComponent(siteKey)}/create-meta${q}`;
      const res = await this.fetchFn(this.url(path), { headers: this.headers() });
      const body = await res.json().catch(() => ({}));
      if (!res.ok && res.status !== 202)
        throw new HttpError(res.status, body.error || `HTTP ${res.status}`);
      return res.status === 202 ? { status: 202, body } : { status: 200, body };
    }
    createTicket(siteKey, body) {
      return this.request(`/api/jira/${encodeURIComponent(siteKey)}/tickets`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
    }
    async createResult(siteKey, cmdId) {
      const path = `/api/jira/${encodeURIComponent(siteKey)}/tickets/${encodeURIComponent(cmdId)}`;
      const res = await this.fetchFn(this.url(path), { headers: this.headers() });
      const body = await res.json().catch(() => ({}));
      if (!res.ok && res.status !== 202)
        throw new HttpError(res.status, body.error || `HTTP ${res.status}`);
      return res.status === 202 ? { status: 202, body } : { status: 200, body };
    }
    interrupt(host, id) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/interrupt`, { method: "POST" });
    }
    setSummary(host, id, summary) {
      return this.request(`/api/agents/${encodeURIComponent(host)}/sessions/${encodeURIComponent(id)}/summary`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ summary })
      });
    }
  }

  // src/audio/audio.ts
  var WS_OPEN = 1;
  var FINALIZE_TIMEOUT_MS = 15000;
  function errorMessage(err) {
    return err instanceof Error ? err.message : String(err);
  }
  function unavailableResult(reason) {
    return { type: "audio_result", transcript: { text: "", unavailable: true, reason } };
  }

  class AudioRecorder {
    bridge;
    wsCtor;
    now;
    ws = null;
    micOn = false;
    recording = false;
    startedAt = null;
    unsubscribeFramesFn = null;
    constructor(opts) {
      this.bridge = opts.bridge;
      this.wsCtor = opts.WebSocket ?? globalThis.WebSocket;
      this.now = opts.now ?? (() => Date.now());
    }
    isRecording() {
      return this.recording;
    }
    handleUnexpectedEnd = () => {
      this.recording = false;
      this.unsubscribeFrames();
      this.teardownMic();
    };
    async start(url) {
      const Ctor = this.wsCtor;
      if (!Ctor) {
        throw new Error("WebSocket constructor not available");
      }
      const ws = new Ctor(url);
      this.ws = ws;
      ws.addEventListener("close", this.handleUnexpectedEnd);
      ws.addEventListener("error", this.handleUnexpectedEnd);
      try {
        await new Promise((resolve, reject) => {
          const onOpen = () => {
            cleanup();
            resolve();
          };
          const onError = (ev) => {
            cleanup();
            reject(new Error(ev.message ?? "WS error"));
          };
          const cleanup = () => {
            ws.removeEventListener("open", onOpen);
            ws.removeEventListener("error", onError);
          };
          ws.addEventListener("open", onOpen);
          ws.addEventListener("error", onError);
        });
      } catch (err) {
        this.detachPermanentListeners(ws);
        this.ws = null;
        throw err;
      }
      try {
        await this.bridge.audioControl(true);
      } catch (err) {
        this.detachPermanentListeners(ws);
        try {
          ws.close();
        } catch {}
        this.ws = null;
        throw new Error(`audioControl(true) failed: ${errorMessage(err)}`);
      }
      this.micOn = true;
      if (this.ws !== ws || ws.readyState !== WS_OPEN) {
        this.detachPermanentListeners(ws);
        await this.teardownMic();
        try {
          ws.close();
        } catch {}
        if (this.ws === ws)
          this.ws = null;
        throw new Error("WS closed while turning the mic on");
      }
      this.recording = true;
      this.startedAt = this.now();
      this.unsubscribeFramesFn = this.bridge.onAudioFrame((pcm) => this.sendFrame(pcm));
    }
    async stopAndFinalize() {
      await this.teardownMic();
      this.unsubscribeFrames();
      this.recording = false;
      const ws = this.ws;
      this.ws = null;
      if (!ws) {
        return unavailableResult("not recording");
      }
      this.detachPermanentListeners(ws);
      return new Promise((resolve) => {
        let settled = false;
        const timer = setTimeout(() => {
          finish(unavailableResult("timed out waiting for transcription"));
        }, FINALIZE_TIMEOUT_MS);
        const cleanup = () => {
          clearTimeout(timer);
          ws.removeEventListener("message", onMessage);
          ws.removeEventListener("close", onCloseOrError);
          ws.removeEventListener("error", onCloseOrError);
        };
        const finish = (result) => {
          if (settled)
            return;
          settled = true;
          cleanup();
          try {
            ws.close();
          } catch {}
          resolve(this.withDuration(result));
        };
        const onMessage = (ev) => {
          if (typeof ev.data !== "string")
            return;
          let parsed;
          try {
            parsed = JSON.parse(ev.data);
          } catch {
            return;
          }
          if (parsed?.type !== "audio_result")
            return;
          finish(parsed);
        };
        const onCloseOrError = () => finish(unavailableResult("connection closed before result"));
        ws.addEventListener("message", onMessage);
        ws.addEventListener("close", onCloseOrError);
        ws.addEventListener("error", onCloseOrError);
        if (ws.readyState === WS_OPEN) {
          try {
            ws.send(JSON.stringify({ type: "finalize" }));
          } catch (err) {
            finish(unavailableResult(`finalize send failed: ${errorMessage(err)}`));
          }
        } else {
          finish(unavailableResult("socket not open"));
        }
      });
    }
    async cancel() {
      await this.teardownMic();
      this.unsubscribeFrames();
      this.recording = false;
      const ws = this.ws;
      this.ws = null;
      if (!ws)
        return;
      this.detachPermanentListeners(ws);
      try {
        ws.close();
      } catch {}
    }
    sendFrame(pcm) {
      const ws = this.ws;
      if (!ws || ws.readyState !== WS_OPEN)
        return;
      try {
        ws.send(pcm);
      } catch {}
    }
    withDuration(result) {
      if (result.durationMs != null || this.startedAt == null)
        return result;
      return { ...result, durationMs: Math.max(0, this.now() - this.startedAt) };
    }
    unsubscribeFrames() {
      if (!this.unsubscribeFramesFn)
        return;
      try {
        this.unsubscribeFramesFn();
      } catch {}
      this.unsubscribeFramesFn = null;
    }
    detachPermanentListeners(ws) {
      ws.removeEventListener("close", this.handleUnexpectedEnd);
      ws.removeEventListener("error", this.handleUnexpectedEnd);
    }
    async teardownMic() {
      if (!this.micOn)
        return;
      this.micOn = false;
      try {
        await this.bridge.audioControl(false);
      } catch {}
    }
  }

  // src/audio/dictation.ts
  function buildAudioWsUrl(hubUrl, token) {
    const wsBase = hubUrl.replace(/^https:\/\//i, "wss://").replace(/^http:\/\//i, "ws://").replace(/\/$/, "");
    return `${wsBase}/audio?auth=${encodeURIComponent(token)}`;
  }
  function errorMessage2(err) {
    return err instanceof Error ? err.message : String(err);
  }

  class HubAudioDictation {
    hubClient;
    recorder;
    hubUrl;
    onResultCb = null;
    delivered = false;
    generation = 0;
    connected = false;
    constructor(opts) {
      this.hubClient = opts.hubClient;
      this.recorder = opts.recorder;
      this.hubUrl = opts.hubUrl;
    }
    start(onResult) {
      this.onResultCb = onResult;
      this.delivered = false;
      this.connected = false;
      const gen = ++this.generation;
      this.connect(gen);
    }
    async connect(gen) {
      let token;
      try {
        const res = await this.hubClient.wsToken();
        token = res.token;
      } catch (err) {
        if (gen !== this.generation)
          return;
        this.deliverUnavailable(`ws token fetch failed: ${errorMessage2(err)}`);
        return;
      }
      if (gen !== this.generation)
        return;
      const url = buildAudioWsUrl(this.hubUrl, token);
      try {
        await this.recorder.start(url);
      } catch (err) {
        if (gen !== this.generation)
          return;
        this.deliverUnavailable(`mic/connect failed: ${errorMessage2(err)}`);
        return;
      }
      if (gen !== this.generation) {
        this.recorder.cancel();
        return;
      }
      this.connected = true;
    }
    deliverUnavailable(reason) {
      if (this.delivered)
        return;
      this.delivered = true;
      this.onResultCb?.({ text: "", unavailable: true, reason });
    }
    stop() {
      if (!this.connected) {
        this.generation++;
        this.delivered = true;
        return;
      }
      this.finish();
    }
    async finish() {
      const result = await this.recorder.stopAndFinalize();
      if (this.delivered)
        return;
      this.delivered = true;
      const t = result.transcript;
      this.onResultCb?.({
        text: t?.text ?? "",
        unavailable: t?.unavailable,
        reason: t?.reason,
        durationMs: result.durationMs
      });
    }
    cancel() {
      this.generation++;
      this.delivered = true;
      this.recorder.cancel();
    }
  }

  // src/audio/mic-bridge.ts
  function base64ToBytes2(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0;i < bin.length; i++)
      out[i] = bin.charCodeAt(i);
    return out;
  }

  class MentraMicBridge {
    session;
    frameCbs = new Set;
    unsubscribeChunks = null;
    constructor(session) {
      this.session = session;
    }
    async audioControl(on) {
      if (on) {
        if (this.unsubscribeChunks)
          return;
        this.unsubscribeChunks = this.session.mic.onAudioChunk((chunk) => this.handleChunk(chunk));
        return;
      }
      const unsub = this.unsubscribeChunks;
      this.unsubscribeChunks = null;
      if (unsub) {
        try {
          unsub();
        } catch {}
      }
    }
    onAudioFrame(cb) {
      this.frameCbs.add(cb);
      return () => {
        this.frameCbs.delete(cb);
      };
    }
    handleChunk(chunk) {
      if (!this.unsubscribeChunks)
        return;
      if (!chunk || typeof chunk.data !== "string" || chunk.data.length === 0)
        return;
      let pcm;
      try {
        pcm = base64ToBytes2(chunk.data);
      } catch {
        return;
      }
      for (const cb of this.frameCbs)
        cb(pcm);
    }
  }

  // src/display/debounce.ts
  function createTrailingDebounce(fn, waitMs) {
    let timer = null;
    let lastInvokeAt = -Infinity;
    let pending;
    const invoke = (value) => {
      lastInvokeAt = Date.now();
      timer = null;
      fn(value);
    };
    const debounced = (value) => {
      pending = value;
      const sinceLastInvoke = Date.now() - lastInvokeAt;
      if (timer === null && sinceLastInvoke >= waitMs) {
        invoke(value);
        pending = undefined;
        return;
      }
      if (timer !== null)
        clearTimeout(timer);
      timer = setTimeout(() => {
        const v = pending;
        pending = undefined;
        invoke(v);
      }, waitMs);
    };
    debounced.cancel = () => {
      if (timer !== null) {
        clearTimeout(timer);
        timer = null;
      }
      pending = undefined;
    };
    return debounced;
  }
  function capContent(content, maxChars) {
    if (content.length <= maxChars)
      return content;
    return content.slice(content.length - maxChars);
  }

  // src/display/mentra.ts
  var CANVAS_WIDTH = 576;
  var CANVAS_HEIGHT = 288;
  var LINE_HEIGHT_PX = 40;
  var RENDER_DEBOUNCE_MS = 120;
  var MAX_CONTENT_CHARS = 2000;
  var BOX_BORDER_WIDTH = 1;
  var BOX_BORDER_RADIUS = 12;
  var BOX_PADDING = 2;
  var BOX_INSET = 2 * (BOX_PADDING + BOX_BORDER_WIDTH);
  var STATUS_WIDTH = 120;
  var LINES_SHAPE = "lines";
  var GESTURE_MAP = {
    single_tap: "tap",
    double_tap: "doubleTap",
    swipe_up: "scrollUp",
    swipe_down: "scrollDown"
  };
  function sessionSignature(bottom) {
    return `session:${bottom.mode}:${boxLineCount(bottom)}`;
  }
  function orSpace(content) {
    return content.length === 0 ? " " : content;
  }
  function cap(text) {
    return orSpace(capContent(text, MAX_CONTENT_CHARS));
  }
  function buildLinesScene(model) {
    return [
      {
        type: "text",
        id: "main",
        box: { x: 0, y: 0, w: CANVAS_WIDTH, h: CANVAS_HEIGHT },
        text: cap(model.lines.join(`
`))
      }
    ];
  }
  function buildSessionScene(model) {
    const boxLines = boxLineCount(model.bottom);
    const boxHeight = boxLines * LINE_HEIGHT_PX + BOX_INSET;
    const boxY = CANVAS_HEIGHT - boxHeight;
    const inset = BOX_PADDING + BOX_BORDER_WIDTH;
    return [
      {
        type: "text",
        id: "transcript",
        box: { x: 0, y: 0, w: CANVAS_WIDTH, h: boxY },
        text: cap(model.transcriptLines.join(`
`))
      },
      {
        type: "rect",
        id: "boxborder",
        box: { x: 0, y: boxY, w: CANVAS_WIDTH, h: boxHeight },
        style: { border: BOX_BORDER_WIDTH, radius: BOX_BORDER_RADIUS }
      },
      {
        type: "text",
        id: "boxtext",
        box: { x: inset + 1, y: boxY + inset, w: CANVAS_WIDTH - 2 * (inset + 1), h: boxHeight - 2 * inset },
        text: cap(model.bottom.lines.join(`
`))
      },
      {
        type: "text",
        id: "status",
        box: { x: CANVAS_WIDTH - STATUS_WIDTH - inset, y: boxY + inset, w: STATUS_WIDTH, h: LINE_HEIGHT_PX },
        text: cap(model.bottom.status)
      }
    ];
  }

  class MentraDisplay {
    session;
    inputCb = null;
    unsubscribeTouch = null;
    scheduleRender;
    currentPageShape = null;
    constructor(session) {
      this.session = session;
      this.scheduleRender = createTrailingDebounce((elements) => {
        this.push(elements);
      }, RENDER_DEBOUNCE_MS);
    }
    async start() {
      this.currentPageShape = LINES_SHAPE;
      await this.push(buildLinesScene({ type: "lines", lines: [" "] }));
      this.unsubscribeTouch = this.session.input.onTouch(Object.keys(GESTURE_MAP), (data) => {
        const type = GESTURE_MAP[data.kind];
        if (type)
          this.inputCb?.({ type });
      });
    }
    render(model) {
      const shape = model.type === "lines" ? LINES_SHAPE : sessionSignature(model.bottom);
      const elements = model.type === "lines" ? buildLinesScene(model) : buildSessionScene(model);
      if (shape !== this.currentPageShape) {
        this.scheduleRender.cancel();
        this.currentPageShape = shape;
        this.push(elements);
        return;
      }
      this.scheduleRender(elements);
    }
    async push(elements) {
      try {
        await this.session.display.render(elements);
      } catch (err) {
        console.error("[turma] display.render failed:", err);
      }
    }
    onInput(cb) {
      this.inputCb = cb;
    }
    requestExit() {}
    dispose() {
      this.scheduleRender.cancel();
      this.unsubscribeTouch?.();
      this.unsubscribeTouch = null;
      this.inputCb = null;
    }
  }

  // src/display/measure.ts
  var G1_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var renderFormula = (glyphWidth) => (glyphWidth + 1) * 2;
  var CJK_WIDTH = 18;
  var KOREAN_WIDTH = 24;
  var CYRILLIC_WIDTH = 18;
  var LATIN_MAX_WIDTH = 16;
  function uniformScriptWidth(code) {
    if (code >= 44032 && code <= 55215 || code >= 4352 && code <= 4607 || code >= 12592 && code <= 12687) {
      return KOREAN_WIDTH;
    }
    if (code >= 12352 && code <= 12543)
      return CJK_WIDTH;
    if (code >= 19968 && code <= 40959 || code >= 13312 && code <= 19903 || code >= 12288 && code <= 12351 || code >= 65280 && code <= 65519) {
      return CJK_WIDTH;
    }
    if (code >= 1024 && code <= 1279)
      return CYRILLIC_WIDTH;
    return null;
  }
  var charCache = new Map;
  for (const [ch, glyphWidth] of Object.entries(G1_GLYPH_WIDTHS)) {
    charCache.set(ch, renderFormula(glyphWidth));
  }
  function measureChar(ch) {
    const cached = charCache.get(ch);
    if (cached !== undefined)
      return cached;
    const code = ch.codePointAt(0) ?? 0;
    const width = uniformScriptWidth(code) ?? LATIN_MAX_WIDTH;
    charCache.set(ch, width);
    return width;
  }
  function measureText(s) {
    let total = 0;
    for (const ch of s)
      total += measureChar(ch);
    return total;
  }
  function createG2Measure() {
    return measureText;
  }

  // src/shared/phone-state.ts
  function serializePhoneState(state) {
    return {
      now: state.now,
      screen: state.screen,
      session: state.session ? { hostKey: state.session.hostKey, sessionId: state.session.sessionId } : null,
      agents: state.agents,
      orgFilter: state.orgFilter,
      orgColors: state.orgColors,
      autoStartOrgs: state.autoStartOrgs,
      liveTurn: state.liveTurn,
      flash: state.flash,
      flashUntil: state.flashUntil
    };
  }

  // src/background/storage.ts
  class MentraStorage {
    session;
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      try {
        const raw = await this.session.storage.get(key);
        return raw ? raw : null;
      } catch (err) {
        console.error("[turma] storage.get failed:", err);
        return null;
      }
    }
    async set(key, value) {
      try {
        await this.session.storage.set(key, value);
      } catch (err) {
        console.error("[turma] storage.set failed:", err);
      }
    }
  }

  // src/background/index.ts
  setDefaultMeasure(createG2Measure());

  class TurmaBackground {
    session;
    storage;
    app = null;
    display = null;
    transition = Promise.resolve();
    constructor(session) {
      this.session = session;
      this.storage = new MentraStorage(session);
      this.registerUiHandlers();
      this.registerLifecycle();
    }
    start() {
      this.enqueue(() => this.applyConfig());
    }
    phase() {
      return this.app ? "running" : "setup";
    }
    enqueue(fn) {
      this.transition = this.transition.then(fn, fn);
      return this.transition;
    }
    async applyConfig() {
      const config = await loadConfig(this.storage);
      this.stopApp();
      if (!isConfigured(config)) {
        await this.renderSetupScreen();
        this.session.ui.send("turma:phase", { phase: "setup" });
        return;
      }
      await this.startApp(config);
      this.session.ui.send("turma:phase", { phase: "running" });
    }
    async startApp(config) {
      const client = new HubClient({ config, fetchFn: globalThis.fetch.bind(globalThis) });
      const liveTail = new LiveTail({ hubClient: client, hubUrl: config.hubUrl });
      const dictation = new HubAudioDictation({
        hubClient: client,
        hubUrl: config.hubUrl,
        recorder: new AudioRecorder({ bridge: new MentraMicBridge(this.session) })
      });
      const display = new MentraDisplay(this.session);
      const app = new App({
        client,
        display,
        dictation,
        liveTail,
        pollMs: config.pollMs ?? DEFAULT_POLL_MS,
        onState: (state) => this.session.ui.send("turma:state", serializePhoneState(state)),
        onEnterSession: (hostKey, sessionId) => this.session.ui.send("turma:enter-session", { hostKey, sessionId }),
        onRichTail: (sessionId, entries) => this.session.ui.send("turma:rich-tail", { sessionId, entries })
      });
      this.display = display;
      this.app = app;
      await app.start();
      if (this.session.visibility === "background")
        app.pause();
    }
    stopApp() {
      if (this.app) {
        try {
          this.app.pause({ hard: true });
        } catch (err) {
          console.error("[turma] app.pause on teardown failed:", err);
        }
      }
      this.display?.dispose();
      this.app = null;
      this.display = null;
    }
    async renderSetupScreen() {
      try {
        await this.session.display.render([
          {
            type: "text",
            id: "main",
            box: { x: 0, y: 0, w: 576, h: 288 },
            text: `TURMA

Set up on your phone:
open the Turma miniapp
and sign in to your hub.`
          }
        ]);
      } catch (err) {
        console.error("[turma] setup-screen render failed:", err);
      }
    }
    registerUiHandlers() {
      const ui = this.session.ui;
      ui.handle("turma:fetch", async (req) => {
        const res = await fetch(req.url, {
          method: req.method ?? "GET",
          headers: req.headers,
          body: req.body
        });
        const bodyText = await res.text();
        return { status: res.status, ok: res.ok, bodyText };
      });
      ui.handle("turma:storage-get", async ({ key }) => ({ value: await this.storage.get(key) }));
      ui.handle("turma:storage-set", async ({ key, value }) => {
        await this.storage.set(key, value);
        return { ok: true };
      });
      ui.handle("turma:config-changed", async () => {
        await this.enqueue(() => this.applyConfig());
        return { phase: this.phase() };
      });
      ui.handle("turma:cmd", (cmd) => {
        const app = this.app;
        if (!app)
          return { ok: false };
        switch (cmd.kind) {
          case "enterSession":
            app.enterSession(cmd.sessionId, cmd.hostKey);
            break;
          case "setOrgFilter":
            app.setOrgFilter(cmd.siteKey);
            break;
          case "setAutoStartOrg":
            app.setAutoStartOrg(cmd.siteKey, cmd.enabled);
            break;
        }
        return { ok: true };
      });
      ui.handle("turma:get-state", () => ({
        phase: this.phase(),
        state: this.app ? serializePhoneState(this.app.getState()) : null
      }));
      ui.onOpen(() => {
        this.session.ui.send("turma:phase", { phase: this.phase() });
        if (this.app)
          this.session.ui.send("turma:state", serializePhoneState(this.app.getState()));
      });
    }
    registerLifecycle() {
      this.session.on("visibility", (v) => {
        const app = this.app;
        if (!app)
          return;
        if (v === "foreground")
          app.resume();
        else
          app.pause();
      });
      this.session.on("beforeDisconnect", () => {
        this.app?.pause({ hard: true });
      });
      this.session.on("disconnect", () => {
        this.app?.pause({ hard: true });
      });
    }
  }
  registerMiniapp((session) => {
    new TurmaBackground(session).start();
  });
})();
